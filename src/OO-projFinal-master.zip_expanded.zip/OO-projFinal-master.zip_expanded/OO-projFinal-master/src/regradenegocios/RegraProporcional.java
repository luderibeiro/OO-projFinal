package regradenegocios;

public class RegraProporcional extends BaseDeCalculo {
	private float capacidade;
	
	private float calculoCapacidade(){
		capacidade = 0; //Só inicialização da variável
		
		//Calculo de capacidade de pagamento
		
		return capacidade;
	}
}

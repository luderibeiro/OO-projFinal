package regradenegocios;


public class SubCategoria extends Categoria {
	protected String descricao;
	
}

package regradenegocios;

public class BaseDeCalculo {
	protected void calculoBase(){
		
	}
}

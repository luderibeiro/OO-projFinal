package regradenegocios;

public class RegraIgualitaria extends BaseDeCalculo {
	private float DespesasMensais;
	
	private float calculoDespesas(){
		float total = 0;
		
		//Calculo das despesas
		
		return total;
	}
}

package regradenegocios;
import javax.swing.JOptionPane;

public class Categoria extends Despesas {
	private String descricao;
	private SubCategoria subCat;
	
	protected void cadastrarCategoria() {
		descricao = JOptionPane.showInputDialog("Digite o nome da Categoria: ");
	}
	protected void cadastrarSubCategoria(){
		subCat.descricao= JOptionPane.showInputDialog("Digite o noem da Subcategoria: ");
	}
}
